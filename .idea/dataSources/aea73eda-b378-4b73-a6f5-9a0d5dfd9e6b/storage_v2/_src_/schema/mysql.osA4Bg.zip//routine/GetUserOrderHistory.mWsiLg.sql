create
    definer = root@localhost procedure GetUserOrderHistory(IN p_CustomerID int)
BEGIN
    SELECT 
        Order_id,
        Order_Date,
        Total_amount,
        payment_status,
        shipping_status
    FROM 
        Orders
    WHERE 
        Customer_id = p_CustomerID
    ORDER BY 
        Order_Date DESC;
END;

