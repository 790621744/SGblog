create
    definer = root@localhost procedure AddOrder(IN p_CustomerID int, IN p_OrderDate date,
                                                IN p_TotalAmount decimal(10, 2), IN p_PaymentStatus varchar(50),
                                                IN p_ShippingStatus varchar(50), IN p_ItemsList text,
                                                IN p_TotalPrice decimal(10, 2))
BEGIN
    DECLARE newOrderID INT;
    DECLARE item TEXT;
    DECLARE itemTitle VARCHAR(255);
    DECLARE itemQuantity INT;
    DECLARE itemPosition INT DEFAULT 1;

    -- 插入订单信息
    INSERT INTO Orders (Customer_id, Order_Date, Total_amount, payment_status, shipping_status)
    VALUES (p_CustomerID, p_OrderDate, p_TotalAmount, p_PaymentStatus, p_ShippingStatus);

    -- 获取新插入的订单ID
    SET newOrderID = LAST_INSERT_ID();

    -- 插入购物车信息
    INSERT INTO ShoppingCartInformation (Items_list, Total_price)
    VALUES (p_ItemsList, p_TotalPrice);

    -- 更新图书库存数量
    -- 假设p_ItemsList是一个以逗号分隔的字符串，如"Title1:2,Title2:3"，表示Title1购买2本，Title2购买3本
    WHILE itemPosition > 0 DO
        SET itemPosition = LOCATE(',', p_ItemsList);
        IF itemPosition = 0 THEN
            SET item = p_ItemsList;
        ELSE
            SET item = LEFT(p_ItemsList, itemPosition - 1);
            SET p_ItemsList = SUBSTRING(p_ItemsList, itemPosition + 1);
        END IF;

        SET itemTitle = LEFT(item, LOCATE(':', item) - 1);
        SET itemQuantity = CAST(SUBSTRING(item, LOCATE(':', item) + 1) AS UNSIGNED);

        UPDATE Books
        SET Stock_quantity = Stock_quantity - itemQuantity
        WHERE Title = itemTitle;
    END WHILE;
END;

